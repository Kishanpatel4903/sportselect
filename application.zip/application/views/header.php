<!DOCTYPE html>
<html lang="en">
  	<head>

        <!-- Config Metas -->
	    <meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Dynamic Metas -->
	    <meta name="description" content="">
	    <meta name="author" content="">
	    <title>Bootstrap + Codeigniter - Create, Read, Update and Delete</title>

        <!-- Static Metas -->	    	    
	    <!-- <link rel="icon" href="../../favicon.ico"> -->
        
        <!-- Tags Link -->
	    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
	    <link href="<?php echo base_url(); ?>assets/css/bootstrap-theme.min.css" rel="stylesheet">
	    <link href="<?php echo base_url(); ?>assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">
	    <link href="<?php echo base_url(); ?>assets/css/theme.css" rel="stylesheet">
	    <script src="<?php echo base_url(); ?>assets/js/ie-emulation-modes-warning.js"></script>

  	</head>
  	<body role="document">

        <!-- Start Responsive Container -->
  		<div class="container theme-showcase" role="main">