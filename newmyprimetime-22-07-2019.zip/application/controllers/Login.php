<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Create
 *
 * @package     Controllers
 * @subpackage  null
 * @category    Controllers
 * @author      Guilherme Gatti
 * @link        null
 */
class Login extends CI_Controller {

	/**
	 * Construct of CI_Controller
	 *
	 * @param  null  Do not have a param
	 * @return null  Do not have a return
	 */
	public function __construct()
	{
	
		/**
		 * Instead the construct of CI_Controller
		 */
		parent::__construct();
		$this->load->model('register_model');
	}

	/**
	 * Index of the create page
	 *
	 * @param  null  Do not have a param
	 * @return null  Do not have a return
	 */
	public function index()
	{
		session_check();
		$this->load->view('login');
		
	}

	public function check(){
		if($this->input->post('submit'))
		 {
			 $e=$this->input->post('email');
			 $p=$this->input->post('password');
			 $que=$this->db->query("select * from users where email='".$e."' and password='$p'")->result();
			 if(count($que) > 0)
			 {
			 	$this->session->set_userdata("verified", $que[0]->id);
			 	$this->session->set_flashdata('mess', array('message' => 'login details are correct','class' => 'alert alert-success'));
			 	if($this->input->post('flag') == '1'){
			 	 	redirect('/admin/dashbaord');
			 	}else{
			 		redirect('/myprofile');
			 	}
			 }
			 else
			 {
			 	$this->session->set_flashdata('mess', array('message' => 'Invalid login details','class' => 'alert alert-daner'));
			 } 
		 }
		 redirect('/login');
	}
}