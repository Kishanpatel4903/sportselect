<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Create
 *
 * @package     Controllers
 * @subpackage  null
 * @category    Controllers
 * @author      Guilherme Gatti
 * @link        null
 */
class Myprofile extends CI_Controller {

	/**
	 * Construct of CI_Controller
	 *
	 * @param  null  Do not have a param
	 * @return null  Do not have a return
	 */
	public function __construct()
	{

		/**
		 * Instead the construct of CI_Controller
		 */
		parent::__construct();
		$this->load->model('myprofile_model','myprof');
	}

	/**
	 * Index of the create page
	 *
	 * @param  null  Do not have a param
	 * @return null  Do not have a return
	 */
	public function index()
	{
		$sess = $this->session->userdata("verified");
		if(empty($sess)){
			redirect('/login');
		}
		$data['data'] = $this->myprof->fetch_record($sess);
		$data['userdata'] = $this->myprof->getAllUserData();
		$this->load->view('myprofile',$data);
	}

	public function testpdf(){
		$this->load->view('testpdf');
	}

	public function editprofile(){
		$sess = $this->session->userdata("verified");
		$data['data'] = $this->myprof->fetch_record($sess);
		$this->load->view('profile_edit',$data);
	}

	public function userDetails(){
		$data['data'] = $this->myprof->fetchRecordByName($_POST['name']);
		$data['userdata'] = $this->myprof->getAllUserData();
		$response = $this->load->view('myprofile',$data,TRUE);
   		echo $response;
	}

	public function profileupdate(){

		if($this->input->post('tab') == "tab1"){
			if($_FILES){
				$url = "../uploads";
				$image=basename($_FILES['profile_img']['name']);
				$image=str_replace(' ','|',$image);
				$type = explode(".",$image);
				$type = $type[count($type)-1];
				if (in_array($type,array('jpg','jpeg','png','gif')))
				{
					$tmppath="uploads/".$image.".".$type;
					if(is_uploaded_file($_FILES["profile_img"]["tmp_name"]))
					{
						move_uploaded_file($_FILES['profile_img']['tmp_name'],$tmppath);
					}
				}
			}
			else{
				$image = $this->input->post('oldimg');
			}			

			$data = array(
				"email" => $this->input->post('email'),
				"profile_img" => $image,
				"first_name" => $this->input->post('fname'),
				"last_name" => $this->input->post('lname'),
			);
		}
		elseif($this->input->post('tab') == "tab2"){
			$data = array(
				"height" => $this->input->post('height'),
				"weight" => $this->input->post('weight'),
				"date" => $this->input->post('age'),
				"service_location" => $this->input->post('service_location'),
				"user_language" => $this->input->post('user_language'),
				"family_status" => $this->input->post('family_status'),
				"outfitter" => $this->input->post('outfitter'),
				"shoesize" => $this->input->post('shoesize'),
			);
		}
		
			
		elseif($this->input->post('tab') == "tab3"){
			$data = array(
				"prefer_side" => $this->input->post('prefer_side'),
				"first_position" => $this->input->post('first_position'),
				"second_position" => $this->input->post('second_position'),
				"agentname" => $this->input->post('agentname'),
				"salary" => $this->input->post('salary'),
				"jersey_number" => $this->input->post('jersey_number'),
				"academy" => $this->input->post('academy'),
				"statisticslink" => $this->input->post('statisticslink'),
				"offeraccept" => $this->input->post('offeraccept'),
				"injuries" => $this->input->post('injuries'),
			);
		}
		elseif($this->input->post('tab') == "tab4"){
			$data = array(
				"prefer_side" => $this->input->post('prefer_side'),
				"other" => $this->input->post('other'),
			);
		}
		
		$query = $this->myprof->profile_update($data);
		if($query):
			$this->session->set_flashdata('mess', array('message' => 'Your data has been added successfully.','class' => 'alert alert-success'));
			redirect('/myprofile/editprofile');
		endif;
	}
}