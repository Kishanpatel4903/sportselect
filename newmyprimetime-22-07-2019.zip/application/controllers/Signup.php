<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Create
 *
 * @package     Controllers
 * @subpackage  null
 * @category    Controllers
 * @author      Guilherme Gatti
 * @link        null
 */
class Signup extends CI_Controller {

	/**
	 * Construct of CI_Controller
	 *
	 * @param  null  Do not have a param
	 * @return null  Do not have a return
	 */
	public function __construct()
	{

		/**
		 * Instead the construct of CI_Controller
		 */
		parent::__construct();
		$this->load->model('signup_model');
	}

	/**
	 * Index of the create page
	 *
	 * @param  null  Do not have a param
	 * @return null  Do not have a return
	 */
	public function index()
	{
		session_check();
		$this->load->view('signup');
	}

	public function insertfunction(){
		
		$passkey = $this->input->post('passkey');
		if(!isset($passkey) && empty($passkey)){
			$returnlink = $this->signup_model->passkey_check(sha1($passkey));	
			if($returnlink){
				$data = array(
					"email" => $this->input->post('email'),
					"password" => $this->input->post('pass'),
					"first_name" => $this->input->post('fname'),
					"last_name" => $this->input->post('lname'),
					"height" => $this->input->post('height'),
					"weight" => $this->input->post('weight'),
					"country" => $this->input->post('country'),
					"date" => $this->input->post('age'),
					"service_location" => $this->input->post('service_location'),
					"user_language" => $this->input->post('user_language'),
					"career_type" => $this->input->post('career_type'),
					"salary" => $this->input->post('salary'),
					"prefer_side" => $this->input->post('prefer_side'),
					"career_grab" => $this->input->post('career_grab'),
					"family_status" => $this->input->post('family_status'),
					"jersey_number" => $this->input->post('jersey_number'),
					"first_availability" => $this->input->post('first_availability'),
					"second_availability" => $this->input->post('second_availability'),
					"other" => $this->input->post('other'),
					"first_position" => $this->input->post('first_position'),
					"second_position" => $this->input->post('second_position'),
					"status" => "1"
				);
				$query = $this->signup_model->register($data);
				$this->session->set_flashdata('mess', array('message' => 'Your data has been added successfully.','class' => 'alert alert-success'));
				$this->session->set_userdata("verified", $this->db->insert_id());
				redirect('/myprofile');
			}else{
				$this->session->set_flashdata('mess', array('message' => 'Your passkey is not match with original.','class' => 'alert alert-danger'));
				redirect('/signup?passkey=	'.$this->input->post('oldpasskey'));
			}
		}else{

			$url = "../uploads";
			$image=basename($_FILES['profile_img']['name']);
			$image=str_replace(' ','|',$image);
			$type = explode(".",$image);
			$type = $type[count($type)-1];
			if (in_array($type,array('jpg','jpeg','png','gif')))
			{
				$tmppath="uploads/".$image.".".$type;
				if(is_uploaded_file($_FILES["profile_img"]["tmp_name"]))
				{
					move_uploaded_file($_FILES['profile_img']['tmp_name'],$tmppath);
				}
			}


			$data = array(
				"email" => $this->input->post('email'),
				"password" => $this->input->post('pass'),
				"first_name" => $this->input->post('fname'),
				"last_name" => $this->input->post('lname'),
				"profile_img" => $image,
				"height" => $this->input->post('height'),
				"weight" => $this->input->post('weight'),
				"country" => $this->input->post('country'),
				"date" => $this->input->post('age'),
				"service_location" => $this->input->post('service_location'),
				"user_language" => $this->input->post('user_language'),
				"injuries" => $this->input->post('injuries'),
				"outfitter" => $this->input->post('outfitter'),
				"shoesize" => $this->input->post('shoesize'),
				"agentname" => $this->input->post('agentname'),
				"academy" => $this->input->post('academy'),
				"statisticslink" => $this->input->post('statisticslink'),
				"offeraccept" => $this->input->post('offeraccept'),
				"salary" => $this->input->post('salary'),
				"prefer_side" => $this->input->post('prefer_side'),
				"family_status" => $this->input->post('family_status'),
				"jersey_number" => $this->input->post('jersey_number'),
				"first_availability" => $this->input->post('first_availability'),
				"second_availability" => $this->input->post('second_availability'),
				"other" => $this->input->post('other'),
				"first_position" => $this->input->post('first_position'),
				"second_position" => $this->input->post('second_position'),
			);
			$query = $this->signup_model->register($data);
			if($query){
				$this->session->set_userdata("verified", $this->db->insert_id());
				redirect('/myprofile');
			}
		}
	}

	public function logout(){
		$this->session->sess_destroy();
		redirect('/login');
	}
}