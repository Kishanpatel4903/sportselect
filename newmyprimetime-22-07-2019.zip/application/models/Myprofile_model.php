<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Index_model
 *
 * @package    Models
 * @subpackage null
 * @category   Models
 * @author     Guilherme Gatti
 * @link       null
 */
class Myprofile_model extends CI_Model{

	/**
	 * Construct of CI_Model
	 *
	 * @param  null  Do not have a param
	 * @return null  Do not have a return
	 */
	public function __construct()
	{
	
		/**
		 * Instead the construct of CI_Model
		 */
		parent::__construct();
	}

	public function fetch_record($id){
		$this->db->where('id', $id);
		return $query = $this->db->get('users')->row();

	}

	public function getAllUserData(){
		$this->db->where('id!=', 1);
		$this->db->select('first_name,last_name');
		return $query = $this->db->get('users')->result();		
	}

	public function fetchRecordByName($name){
		$this->db->where('first_name', $name);
		return $query = $this->db->get('users')->row();
	}

	public function profile_update($data){
		//pre($data);
		return $this->db->update("users",$data,array("id" => $this->session->userdata("verified")));
		
	}



}