<!DOCTYPE html>
<html>
<head>
   <title></title>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="<?php echo base_url(); ?>adminassets/css/font-awesome.min.css">
   <link rel="stylesheet" href="<?php echo base_url(); ?>adminassets/fonts/injuries-icon/flaticon.css">
   <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>adminassets/css/bootstrap.min.css">
   <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>adminassets/css/header.css">
   <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>adminassets/css/style.css">
   <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>adminassets/css/responsive.css">
   <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>adminassets/css/profileedit.css">
</head>
<body>
   <div class="homepage">
      <header>
         <nav class="navbar navbar-inverse navbar-expand-xl navbar-dark">
            <div class="navbar-header d-flex col">
               <a class="navbar-brand" href="index.html"><i class="fa fa-cube"></i><b>Sportselect</b></a>      
               <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle navbar-toggler ml-auto">
                  <span class="navbar-toggler-icon"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
               </button>
            </div>
            <!-- Collection of nav links, forms, and other content for toggling -->
            <div id="navbarCollapse" class="collapse navbar-collapse justify-content-start">
               <form class="navbar-form form-inline">
                  <div class="input-group search-box">                        
                     <input type="text" id="search" class="form-control" placeholder="Search here...">
                     <span class="input-group-addon"><i class="fa fa-search"></i></span>
                  </div>
               </form>
               <ul class="nav navbar-nav navbar-right ml-auto">
                  <li class="nav-item active"><a href="#" class="nav-link"><i class="fa fa-home"></i><span>Home</span></a></li>
                  <li class="nav-item"><a href="#" class="nav-link"><i class="fa fa-pie-chart"></i><span>Transfer Market</span></a></li>
                  <li class="nav-item"><a href="#" class="nav-link"><i class="fa fa-envelope"></i><span>Messages</span></a></li>
                  <li class="nav-item dropdown">
                     <a href="#" class="nav-link" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-bell"></i><span>Notifications</span></a>
                  </a>
                  <ul class="dropdown-menu noti-boxmenu">
                     <li class="head text-light orangebackcolor">
                        <div class="row">
                           <div class="col-lg-12 col-sm-12 col-12">
                              <span class="colorwhite">Notifications (3)</span>
                              <a href="" class="float-right colorwhite">Mark all as read</a>
                           </div>
                        </li>
                        <li class="notification-box">
                           <div class="row">
                              <div class="col-lg-3 col-sm-3 col-3 text-center">
                                 <img src="<?php echo base_url(); ?>adminassets/images/user.jpg" class="w-50 rounded-circle">
                              </div>    
                              <div class="col-lg-8 col-sm-8 col-8">
                                 <strong class="text-info">David John</strong>
                                 <div>
                                    Lorem ipsum dolor sit amet, consectetur
                                 </div>
                                 <small class="text-warning">1/1/2019, 15:00</small>
                              </div>    
                           </div>
                        </li>
                        <li class="notification-box bg-gray">
                           <div class="row">
                              <div class="col-lg-3 col-sm-3 col-3 text-center">
                                 <img src="<?php echo base_url(); ?>adminassets/images/user.jpg" class="w-50 rounded-circle">
                              </div>    
                              <div class="col-lg-8 col-sm-8 col-8">
                                 <strong class="text-info">David John</strong>
                                 <div>
                                    Lorem ipsum dolor sit amet, consectetur
                                 </div>
                                 <small class="text-warning">1/1/2019, 15:00</small>
                              </div>    
                           </div>
                        </li>
                        <li class="notification-box">
                           <div class="row">
                              <div class="col-lg-3 col-sm-3 col-3 text-center">
                                 <img src="<?php echo base_url(); ?>adminassets/images/user.jpg" class="w-50 rounded-circle">
                              </div>    
                              <div class="col-lg-8 col-sm-8 col-8">
                                 <strong class="text-info">David John</strong>
                                 <div>
                                    Lorem ipsum dolor sit amet, consectetur
                                 </div>
                                 <small class="text-warning">1/1/2019, 15:00</small>
                              </div>    
                           </div>
                        </li>
                        <li class="footer orangebackcolor text-center">
                           <a href="" class="text-light colorwhite">View All</a>
                        </li>
                     </ul>
                  </li>
                  <li class="nav-item dropdown">
                     <a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle user-action"><img src="<?php echo base_url(); ?>adminassets/images/user.jpg" class="avatar" alt="Avatar"> Antonio Moreno <b class="caret"></b></a>
                     <ul class="dropdown-menu">
                        <li><a href="<?php echo base_url(); ?>myprofile " class="dropdown-item"><i class="fa fa-user-o"></i> Profile</a></li>

                        <li class="divider dropdown-divider"></li>
                        <li><a href="<?php echo base_url().'signup/logout'; ?>" class="dropdown-item"><i class="fa fa-power-off"></i> Logout</a></li>
                     </ul>
                  </li>
               </ul>
            </div>
         </nav>
      </header>
      <section class="profileeditpage">
         <div class="container-fluid">
            <div class="row">
               <?php  if(isset($mess)){ print_r($mess); } ?>
               <div class="col-md-2" style="background: #fff;">
                  <div class="sidebar">
                     <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item">
                           <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#tab-1" role="tab" aria-controls="pills-home" aria-selected="true">About</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#tab-2" role="tab" aria-controls="pills-profile" aria-selected="false">Personal Details</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#tab-3" role="tab" aria-controls="pills-contact" aria-selected="false">Career</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#tab-4" role="tab" aria-controls="pills-contact" aria-selected="false">Status</a>
                        </li>
                     </ul>
                  </div>
               </div>
               <div class="col-md-10">
                  <div class="tab-content">
                     <div class="tab-pane fade show active" id="tab-1" role="tabpanel" aria-labelledby="pills-home-tab">
                        <div class="profileeditbox">
                           <form class="needs-validation" novalidate enctype='multipart/form-data' action="<?php echo base_url(); ?>myprofile/profileupdate/" method="post">
                              <input type="hidden" name="tab" value="tab1">
                              <h3 class="mb-5">About</h3>
                              <div class="form-row">
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom01">Your Photo </label>
                                    <img height="30px" width="60px" src="<?= site_url().'uploads/'.$data->profile_img ?>">
                                    <div class="custom-file" data-text="Select your file!">
                                       <input type="file" class="custom-file-input" id="validatedCustomFile" required value="">
                                       <input type="hidden" name="oldimg" value="<?= $data->profile_img ?>">
                                       <label class="custom-file-label" for="validatedCustomFile">Choose file...</label>
                                       <div class="invalid-feedback">Example invalid custom file feedback</div>
                                    </div>
                                    <!-- <div class="file-upload-wrapper custom-file" data-text="Select your file!">
                                     <input name="file-upload-field" type="file" class="file-upload-field custom-file-input" value="">
                                  </div>  -->
                               </div>
                               <div class="col-md-6 mb-3">
                                 <label for="validationCustom01">First name</label>
                                 <input type="text" name="fname" class="form-control" id="validationCustom01" value="<?= $data->first_name ?>"  required>
                                 <div class="valid-feedback">
                                    Looks good!
                                 </div>
                              </div>
                              <div class="col-md-6 mb-3">
                                 <label for="validationCustom02">Last name</label>
                                 <input type="text" name="lname" class="form-control" id="validationCustom02" value="<?= $data->last_name ?>"   required>
                                 <div class="valid-feedback">
                                    Looks good!
                                 </div>
                              </div>
                              <div class="col-md-6 mb-3">
                                 <label for="validationCustom02">Your email</label>
                                 <input type="email" name="email" class="form-control" id="validationCustom02" value="<?= $data->email ?>" readonly required>
                                 <div class="valid-feedback">
                                    Looks good!
                                 </div>
                              </div>
                           </div>
                           <button class="attributebtn" type="submit">Submit</button>
                        </form>
                     </div>
                  </div>
                  <div class="tab-pane fade" id="tab-2" role="tabpanel" aria-labelledby="pills-profile-tab">
                     <div class="profileeditbox">
                        <form class="needs-validation" novalidate enctype='multipart/form-data' action="<?php echo base_url(); ?>myprofile/profileupdate/" method="post">
                           <input type="hidden" name="tab" value="tab2">
                           <h3 class="mb-4">Personal Details</h3>
                           <div class="form-row">

                              <div class="col-md-4 mb-3">
                                 <label for="validationCustom01">Height</label>
                                 <input type="number" name="height" class="form-control" id="validationCustom01" value="<?= $data->height ?>" required min="50" max="80">
                                 <div class="valid-feedback">
                                    Looks good!
                                 </div>
                              </div>
                              <div class="col-md-4 mb-3">
                                 <label for="validationCustom02">Weight</label>
                                 <input type="number" name="weight" class="form-control" id="validationCustom02" value="<?= $data->weight ?>"  required>
                                 <div class="valid-feedback">
                                    Looks good!
                                 </div>
                              </div>
                              <div class="col-md-4 mb-3">
                                 <label for="validationCustom02">Date of birth</label>
                                 <input type="date" name="age" class="form-control" id="validationCustom02" value="<?= $data->date ?>"  required>
                                 <div class="valid-feedback">
                                    Looks good!
                                 </div>
                              </div>


                              <div class="col-md-4 mb-3">
                                 <div class="form-group">
                                    <label for="validationCustom02">Living</label>
                                    <select name="service_location" class="custom-select" required>
                                       <option value="separate" <?php if($data->service_location == 'separate'){ echo "selected"; } ?>>Separate</option>
                                       <option value="share" <?php if($data->service_location == 'share'){ echo "selected"; } ?>>Share</option>
                                       <option value="none" <?php if($data->service_location == 'none'){ echo "selected"; } ?>>None</option>
                                    </select>
                                    <div class="invalid-feedback">Example invalid custom select feedback</div>
                                 </div>
                              </div>
                              <div class="col-md-4 mb-3">
                                 <label for="validationCustom01">languages</label>
                                 <select class="custom-select" name="user_language" required>
                                    <option value="AF">Afrikanns</option>
                                    <option value="SQ">Albanian</option>
                                    <option value="AR">Arabic</option>
                                    <option value="HY">Armenian</option>
                                    <option value="EU">Basque</option>
                                    <option value="BN">Bengali</option>
                                    <option value="BG">Bulgarian</option>
                                    <option value="CA">Catalan</option>
                                    <option value="KM">Cambodian</option>
                                    <option value="ZH">Chinese (Mandarin)</option>
                                    <option value="HR">Croation</option>
                                    <option value="CS">Czech</option>
                                    <option value="DA">Danish</option>
                                    <option value="NL">Dutch</option>
                                    <option value="EN">English</option>
                                    <option value="ET">Estonian</option>
                                    <option value="FJ">Fiji</option>
                                    <option value="FI">Finnish</option>
                                    <option value="FR">French</option>
                                    <option value="KA">Georgian</option>
                                    <option value="DE">German</option>
                                    <option value="EL">Greek</option>
                                    <option value="GU">Gujarati</option>
                                    <option value="HE">Hebrew</option>
                                    <option value="HI">Hindi</option>
                                    <option value="HU">Hungarian</option>
                                    <option value="IS">Icelandic</option>
                                    <option value="ID">Indonesian</option>
                                    <option value="GA">Irish</option>
                                    <option value="IT">Italian</option>
                                    <option value="JA">Japanese</option>
                                    <option value="JW">Javanese</option>
                                    <option value="KO">Korean</option>
                                    <option value="LA">Latin</option>
                                    <option value="LV">Latvian</option>
                                    <option value="LT">Lithuanian</option>
                                    <option value="MK">Macedonian</option>
                                    <option value="MS">Malay</option>
                                    <option value="ML">Malayalam</option>
                                    <option value="MT">Maltese</option>
                                    <option value="MI">Maori</option>
                                    <option value="MR">Marathi</option>
                                    <option value="MN">Mongolian</option>
                                    <option value="NE">Nepali</option>
                                    <option value="NO">Norwegian</option>
                                    <option value="FA">Persian</option>
                                    <option value="PL">Polish</option>
                                    <option value="PT">Portuguese</option>
                                    <option value="PA">Punjabi</option>
                                    <option value="QU">Quechua</option>
                                    <option value="RO">Romanian</option>
                                    <option value="RU">Russian</option>
                                    <option value="SM">Samoan</option>
                                    <option value="SR">Serbian</option>
                                    <option value="SK">Slovak</option>
                                    <option value="SL">Slovenian</option>
                                    <option value="ES">Spanish</option>
                                    <option value="SW">Swahili</option>
                                    <option value="SV">Swedish </option>
                                    <option value="TA">Tamil</option>
                                    <option value="TT">Tatar</option>
                                    <option value="TE">Telugu</option>
                                    <option value="TH">Thai</option>
                                    <option value="BO">Tibetan</option>
                                    <option value="TO">Tonga</option>
                                    <option value="TR">Turkish</option>
                                    <option value="UK">Ukranian</option>
                                    <option value="UR">Urdu</option>
                                    <option value="UZ">Uzbek</option>
                                    <option value="VI">Vietnamese</option>
                                    <option value="CY">Welsh</option>
                                    <option value="XH">Xhosa</option>
                                 </select>
                              </div>
                              <div class="col-md-4 mb-3">
                                 <label for="validationCustom01">Spoken languages</label>
                                 <select class="custom-select" required>
                                    <option value="AF">Afrikanns</option>
                                    <option value="SQ">Albanian</option>
                                    <option value="AR">Arabic</option>
                                    <option value="HY">Armenian</option>
                                    <option value="EU">Basque</option>
                                    <option value="BN">Bengali</option>
                                    <option value="BG">Bulgarian</option>
                                    <option value="CA">Catalan</option>
                                    <option value="KM">Cambodian</option>
                                    <option value="ZH">Chinese (Mandarin)</option>
                                    <option value="HR">Croation</option>
                                    <option value="CS">Czech</option>
                                    <option value="DA">Danish</option>
                                    <option value="NL">Dutch</option>
                                    <option value="EN">English</option>
                                    <option value="ET">Estonian</option>
                                    <option value="FJ">Fiji</option>
                                    <option value="FI">Finnish</option>
                                    <option value="FR">French</option>
                                    <option value="KA">Georgian</option>
                                    <option value="DE">German</option>
                                    <option value="EL">Greek</option>
                                    <option value="GU">Gujarati</option>
                                    <option value="HE">Hebrew</option>
                                    <option value="HI">Hindi</option>
                                    <option value="HU">Hungarian</option>
                                    <option value="IS">Icelandic</option>
                                    <option value="ID">Indonesian</option>
                                    <option value="GA">Irish</option>
                                    <option value="IT">Italian</option>
                                    <option value="JA">Japanese</option>
                                    <option value="JW">Javanese</option>
                                    <option value="KO">Korean</option>
                                    <option value="LA">Latin</option>
                                    <option value="LV">Latvian</option>
                                    <option value="LT">Lithuanian</option>
                                    <option value="MK">Macedonian</option>
                                    <option value="MS">Malay</option>
                                    <option value="ML">Malayalam</option>
                                    <option value="MT">Maltese</option>
                                    <option value="MI">Maori</option>
                                    <option value="MR">Marathi</option>
                                    <option value="MN">Mongolian</option>
                                    <option value="NE">Nepali</option>
                                    <option value="NO">Norwegian</option>
                                    <option value="FA">Persian</option>
                                    <option value="PL">Polish</option>
                                    <option value="PT">Portuguese</option>
                                    <option value="PA">Punjabi</option>
                                    <option value="QU">Quechua</option>
                                    <option value="RO">Romanian</option>
                                    <option value="RU">Russian</option>
                                    <option value="SM">Samoan</option>
                                    <option value="SR">Serbian</option>
                                    <option value="SK">Slovak</option>
                                    <option value="SL">Slovenian</option>
                                    <option value="ES">Spanish</option>
                                    <option value="SW">Swahili</option>
                                    <option value="SV">Swedish </option>
                                    <option value="TA">Tamil</option>
                                    <option value="TT">Tatar</option>
                                    <option value="TE">Telugu</option>
                                    <option value="TH">Thai</option>
                                    <option value="BO">Tibetan</option>
                                    <option value="TO">Tonga</option>
                                    <option value="TR">Turkish</option>
                                    <option value="UK">Ukranian</option>
                                    <option value="UR">Urdu</option>
                                    <option value="UZ">Uzbek</option>
                                    <option value="VI">Vietnamese</option>
                                    <option value="CY">Welsh</option>
                                    <option value="XH">Xhosa</option>
                                 </select>
                              </div>
                              <div class="col-md-4 mb-3">
                                 <label for="validationCustom02">Family status</label>
                                 <select name="family_status" class="custom-select" required>
                                    <option <?php if($data->family_status == 'single'){ echo "selected"; } ?>>single </option>
                                    <option <?php if($data->family_status == 'married'){ echo "selected"; } ?>>married</option>
                                    <option <?php if($data->family_status == 'travelwithpartner'){ echo "selected"; } ?>>travel with partner</option>
                                 </select>
                              </div>
                              <div class="col-md-4 mb-3">
                                 <label for="validationCustom02">Outfitter</label>
                                 <input type="text" name="outfitter" class="form-control" id="validationCustom02" value="<?= $data->outfitter ?>"   required>
                                 <div class="valid-feedback">
                                    Looks good!
                                 </div>
                              </div>
                              <div class="col-md-4 mb-3">
                                 <label for="validationCustom02">Shoe Size</label>
                                 <input type="text" name="shoesize" class="form-control" id="validationCustom02" value="<?= $data->shoesize ?>"  required>
                                 <div class="valid-feedback">
                                    Looks good!
                                 </div>
                              </div>

                           </div>
                           <button class="attributebtn" type="submit">Submit</button>
                        </form>
                     </div>
                  </div>
                  <div class="tab-pane fade" id="tab-3" role="tabpanel" aria-labelledby="pills-contact-tab">
                     <div class="profileeditbox">
                        <form class="needs-validation" novalidate enctype='multipart/form-data' action="<?php echo base_url(); ?>myprofile/profileupdate/" method="post">
                           <input type="hidden" name="tab" value="tab3">
                           <h3 class="mb-4">Career</h3>
                           <div class="form-row">
                              <div class="col-md-3 mb-3">
                                 <label for="validationCustom02">Preferred Side</label>
                                 <select name="prefer_side" class="custom-select" required>
                                    <option <?php if($data->prefer_side == 'right'){ echo "selected"; } ?>>right </option>
                                    <option <?php if($data->prefer_side == 'left'){ echo "selected"; } ?>>left</option>
                                    <option <?php if($data->prefer_side == 'both'){ echo "selected"; } ?>>both</option>
                                 </select>
                              </div>
                              <div class="col-md-3 mb-3">
                                 <label for="validationCustom01">Position(Primary)</label>
                                 <select class="custom-select" name="first_position" required>
                                    <option>goalkeeper </option>
                                    <option>leftback</option>
                                    <option>rightback</option>
                                    <option>centermidfield1</option>
                                    <option>centermidfield2</option>
                                    <option>leftwing</option>
                                    <option>rightwing</option>
                                    <option>centerforward</option>
                                    <option>striker</option>
                                    <option>centerattack</option>
                                 </select>
                              </div>
                              <div class="col-md-3 mb-3">
                                 <label for="validationCustom01">Position(Alternative)</label>
                                 <select class="custom-select" name="second_position" required>
                                    <option>goalkeeper </option>
                                    <option>leftback</option>
                                    <option>rightback</option>
                                    <option>centermidfield1</option>
                                    <option>centermidfield2</option>
                                    <option>leftwing</option>
                                    <option>rightwing</option>
                                    <option>centerforward</option>
                                    <option>striker</option>
                                    <option>centerattack</option>
                                 </select>
                              </div>
                              <div class="col-md-3 mb-3">
                                 <label for="validationCustom01">agent name</label>
                                 <input type="text" name="agentname" class="form-control" id="validationCustom01" value="<?= $data->agentname ?>" required>
                                 <div class="valid-feedback">
                                    Looks good!
                                 </div>
                              </div>
                              <div class="col-md-3 mb-3">
                                 <label for="validationCustom01">desired salary</label>
                                 <input type="number" name="salary" class="form-control" id="validationCustom01" value="<?= $data->salary ?>" required>
                                 <div class="valid-feedback">
                                    Looks good!
                                 </div>
                              </div>
                              <div class="col-md-3 mb-3">
                                 <label for="validationCustom02">jersey number</label>
                                 <input type="number" name="jersey_number" class="form-control" id="validationCustom02" value="<?= $data->jersey_number ?>" required>
                                 <div class="valid-feedback">
                                    Looks good!
                                 </div>
                              </div>
                              <div class="col-md-3 mb-3">
                                 <label for="validationCustom02">contract end</label>
                                 <input type="date" class="form-control" id="validationCustom02"   required>
                                 <div class="valid-feedback">
                                    Looks good!
                                 </div>
                              </div>
                              <div class="col-md-3 mb-3">
                                 <label for="validationCustom02">Youth academy</label>
                                 <input type="text" name="academy" class="form-control" id="validationCustom02" value="<?= $data->academy ?>"   required>
                                 <div class="valid-feedback">
                                    Looks good!
                                 </div>
                              </div>
                              <div class="col-md-3 mb-3">
                                 <label for="validationCustom02">statistics link</label>
                                 <input type="text" name="statisticslink" class="form-control" id="validationCustom02" value="<?= $data->statisticslink ?>" required>
                                 <div class="valid-feedback">
                                    Looks good!
                                 </div>
                              </div>
                              <div class="col-md-3 mb-3">
                                 <label for="validationCustom01">number of offer accepted</label>
                                 <input type="text" name="offeraccept" class="form-control" id="validationCustom02" value="<?= $data->offeraccept ?>" required>
                                 <div class="valid-feedback">
                                    Looks good!
                                 </div>
                              </div>
                              <div class="col-md-3 mb-3">
                                 <label for="validationCustom02">Injuries</label>
                                 <input type="text" name="injuries" class="form-control" id="validationCustom02" value="<?= $data->injuries ?>"  required>
                                 <div class="valid-feedback">
                                    Looks good!
                                 </div>
                              </div>

                           </div>
                           <button class="attributebtn" type="submit">Submit</button>
                        </form>
                     </div>
                  </div>
                  <div class="tab-pane fade" id="tab-4" role="tabpanel" aria-labelledby="pills-contact-tab">
                     <div class="profileeditbox">
                        <form class="needs-validation" novalidate enctype='multipart/form-data' action="<?php echo base_url(); ?>myprofile/profileupdate/" method="post">
                           <input type="hidden" name="tab" value="tab4">
                           <h3 class="mb-4">Status</h3>
                           <div class="form-row">
                              <div class="col-md-3 mb-3">
                                 <label for="validationCustom02">Preferred Side</label>
                                 <select class="custom-select" required>
                                    <option>Availability</option>
                                    <option>Available </option>
                                    <option>happy with contract </option>
                                    <option>unhappy with contract</option>
                                 </select>
                              </div>
                              <div class="col-md-3 mb-3">
                                 <label for="validationCustom02">Preferred Side</label>
                                 <select class="custom-select" required>
                                    <option>Availability</option>
                                    <option>unhappy with coach</option>
                                    <option>unhappy with team mates</option>
                                    <option>unhappy with club</option>
                                    <option>unhappy with living</option>
                                    <option>other</option>
                                 </select>
                              </div>
                              <div class="col-md-3 mb-3">
                                 <label for="validationCustom02">Other</label>
                                 <input type="text" name="other" class="form-control" id="validationCustom01" value="<?= $data->other ?>" required>
                                 <div class="valid-feedback">
                                    Looks good!
                                 </div>
                              </div>
                              <div class="col-md-3 mb-3">
                                 <label for="validationCustom02">Reference ID</label>
                                 <input type="text" class="form-control" id="validationCustom01"   required>
                                 <div class="valid-feedback">
                                    Looks good!
                                 </div>
                              </div>
                           </div>
                           <button class="attributebtn" type="submit">Submit</button>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <footer style="margin-top: 0;">
      <div class="container-fluid">
         <div class="row">
            <div class="col-md-12">
               <p>Copyright &copy; 2019 by Sportselect</p>
            </div>
         </div>
      </div>
   </footer>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>adminassets/js/jquery-3.4.1.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>adminassets/js/bootstrap.min.js"></script>
<script>
         // Example starter JavaScript for disabling form submissions if there are invalid fields
         (function() {
           'use strict';
           window.addEventListener('load', function() {
             // Fetch all the forms we want to apply custom Bootstrap validation styles to
             var forms = document.getElementsByClassName('needs-validation');
             // Loop over them and prevent submission
             var validation = Array.prototype.filter.call(forms, function(form) {
               form.addEventListener('submit', function(event) {
                 if (form.checkValidity() === false) {
                   event.preventDefault();
                   event.stopPropagation();
                }
                form.classList.add('was-validated');
             }, false);
            });
          }, false);
        })();

        $(function(){
           var hash = window.location.hash;
           hash && $('ul.nav.nav-pills a[href="' + hash + '"]').tab('show'); 
           $('ul.nav.nav-pills a').click(function (e) {
              $(this).tab('show');
              var scrollmem = $('body').scrollTop();
              window.location.hash = this.hash;
           });
        });
        $("form").on("change", ".custom-file-input", function(){ 
         $(this).parent(".custom-file").attr("data-text", $(this).val().replace(/.*(\/|\\)/, '') );
         var changeimagetext = $(this).parent(".custom-file").attr("data-text");
         $('.custom-file-label').html(changeimagetext);
      });
   </script>
</body>
</html>