		</div>
        <!-- End Responsive Container -->

        <!-- Load jQuery -->
	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	    <script>window.jQuery || document.write('<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"><\/script>')</script>
	    
	    <!-- Bootstrap Core JavaScript -->
	    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
	    <script src="<?php echo base_url(); ?>assets/js/docs.min.js"></script>
	    
	    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
	    <script src="<?php echo base_url(); ?>assets/js/ie10-viewport-bug-workaround.js"></script>
  	
  	</body>
</html>