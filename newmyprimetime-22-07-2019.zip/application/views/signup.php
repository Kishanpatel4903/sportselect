<!DOCTYPE html>
<html lang="en">
<head>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <link href="<?php echo base_url(); ?>adminassets/css/bootstrap-3.3.5.min.css" rel="stylesheet" />
    <link href="<?php echo base_url(); ?>adminassets/css/paper-bootstrap-wizard.css" rel="stylesheet" />
    <link href="<?php echo base_url(); ?>adminassets/css/demo.css" rel="stylesheet" />
    <link href="<?php echo base_url(); ?>adminassets/css/signup-style.css" rel="stylesheet" />
    <link href="<?php echo base_url(); ?>adminassets/css/themify-icons.css" rel="stylesheet">
</head>
<body>
    <div class="image-container set-full-height" style="background: linear-gradient(rgba(196, 102, 0, 0.6), rgba(155, 89, 182, 0.6));">


        <!--   Big container   -->
        <div class="container">
            <div class="row">
                <div class="col-sm-8 col-sm-offset-2">

                    <!--      Wizard container        -->
                    <div class="wizard-container">

                        <div class="card wizard-card" data-color="orange" id="wizardProfile">
                            <form action="<?php echo base_url().'signup/insertfunction/'; ?>" method="post" name="msform" class="msform" id="msform" enctype='multipart/form-data'>
                                <!--        You can switch " data-color="orange" "  with one of the next bright colors: "blue", "green", "orange", "red", "azure"          -->

                                <div class="wizard-header text-center">
                                    <h3 class="wizard-title">Create your profile</h3>
                                </div>

                                <div class="wizard-navigation">
                                    <div class="progress-with-circle">
                                       <div class="progress-bar" role="progressbar" aria-valuenow="1" aria-valuemin="1" aria-valuemax="10" style="width: 21%;"></div>
                                   </div>
                                   <ul>
                                    <li>
                                        <a href="#about" data-toggle="tab">
                                            <div class="icon-circle">
                                                <i class="ti-user"></i>
                                            </div>
                                            About
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#account" data-toggle="tab">
                                            <div class="icon-circle">
                                                <i class="ti-user"></i>
                                            </div>
                                            Personal
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#address" data-toggle="tab">
                                            <div class="icon-circle">
                                                <i class="ti-map"></i>
                                            </div>
                                            CAREER
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#availability" data-toggle="tab">
                                            <div class="icon-circle">
                                                <i class="ti-map"></i>
                                            </div>
                                            Status
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="tab-content">
                                <div class="tab-pane" id="about">
                                    <h5 class="info-text"> Please tell us more about yourself.</h5>
                                    <div class="row">


                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>First Name <small>(required)</small></label>
                                                <input type="text" name="fname" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Last Name <small>(required)</small></label>
                                                <input name="lname" type="text" class="form-control" placeholder="Last Name">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Email <small>(required)</small></label>
                                                <input name="email" type="email" class="form-control" placeholder="Email">
                                            </div>
                                        </div>
                                        <div class="col-md-6 file-text">
                                            <div class="form-group">
                                                <label>Your Photo </label>
                                                <div class="file-upload-wrapper" data-text="Select your file!">
                                                    <input name="profile_img" type="file" class="file-upload-field" value="">
                                                </div>        
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Password <small>(required)</small></label>
                                                <input name="pass" type="password" class="form-control" placeholder="Password" id="pass">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Confirm Password <small>(required)</small></label>
                                                <input name="cpass" type="password" class="form-control" placeholder=" Password ">
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="tab-pane" id="account">
                                    <h5 class="info-text"> PERSONAL DETAILS </h5>
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label>Height</label>
                                                <input name="height" type="text" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label>Weight</label>
                                                <input name="weight" type="text" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label>Date of Birth</label>
                                                <input name="age" type="date" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label>Living</label>
                                                <select name="service_location" class="form-control">
                                                 <option>Separate</option>
                                                 <option>Share</option>
                                                 <option>None</option>
                                             </select>
                                         </div>
                                     </div>
                                     <div class="col-sm-4">
                                        <div class="form-group">
                                            <label>Country</label>
                                            <input type="text" name="country" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label>Spoken languages</label>
                                            <input type="text" name="user_language" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label>Family Status</label>
                                            <select name="family_status" class="form-control">
                                                <option>Family status </option>
                                                <option>single </option>
                                                <option>married</option>
                                                <option>travel with partner</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label>Outfitter</label>
                                            <input type="text" name="outfitter" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label>Shoe Size</label>
                                            <input type="text" name="shoesize" class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="address">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <h5 class="info-text"> CAREER INFO </h5>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Preferred Side</label>
                                            <select name="prefer_side" class="form-control">
                                              <option>right </option>
                                              <option>left</option>
                                              <option>both</option>
                                          </select>
                                      </div>
                                  </div>
                                  <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Position(Primary)</label>
                                        <select name="first_position" class="form-control">
                                          <option>goalkeeper </option>
                                          <option>leftback</option>
                                          <option>rightback</option>
                                          <option>centermidfield1
                                              <option>centermidfield2</option>
                                              <option>leftwing</option>
                                              <option>rightwing</option>
                                              <option>centerforward</option>
                                              <option>striker</option>
                                              <option>centerattack</option>
                                          </select>
                                      </div>
                                  </div>
                                  <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Position(Alternative)</label>
                                        <select name="second_position" class="form-control">
                                          <option>goalkeeper </option>
                                          <option>leftback</option>
                                          <option>rightback</option>
                                          <option>centermidfield1
                                              <option>centermidfield2</option>
                                              <option>leftwing</option>
                                              <option>rightwing</option>
                                              <option>centerforward</option>
                                              <option>striker</option>
                                              <option>centerattack</option>
                                          </select>
                                      </div>
                                  </div>
                                  <div class="col-md-4">
                                    <div class="form-group">
                                        <label>agent name</label>
                                        <input type="text" name="agentname" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>desired salary</label>
                                        <input type="text" name="salary" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>jersey number</label>
                                        <input type="text" name="jersey_number" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Youth academy</label>
                                        <input type="text" name="academy" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>statistics link</label>
                                        <input type="text" name="statisticslink" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>number of offer accepted</label>
                                        <input type="text" name="offeraccept" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Injuries</label>
                                        <input type="text" name="injuries" class="form-control">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="availability">
                            <div class="row">
                                <div class="col-sm-12">
                                    <h5 class="info-text"> CAREER INFO </h5>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Availability</label>
                                        <select name="first_availability" class="form-control">
                                          <option>Availability</option>
                                          <option>Available </option>
                                          <option>happy with contract </option>
                                          <option>unhappy with contract</option>
                                      </select>
                                  </div>
                              </div>
                              <div class="col-md-4">
                                <div class="form-group">
                                    <label>unhappy with contract</label>
                                    <select name="second_availability" class="form-control">
                                      <option>Availability</option>
                                      <option>unhappy with coach</option>
                                      <option>unhappy with team mates</option>
                                      <option>unhappy with club</option>
                                      <option>unhappy with living</option>
                                      <option>other</option>
                                  </select>
                              </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                                <label>other</label>
                                <input type="text" name="other" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Reference ID</label>
                                <input type="text" name="passkey" class="form-control">
                            </div>
                        </div>


                    </div>
                </div>
            </div>
            <div class="wizard-footer">
                <div class="pull-right">
                    <input type='button' class='btn btn-next btn-fill btn-warning btn-wd' name='next' value='Next' />
                    <input type='submit' class='btn btn-finish btn-fill btn-warning btn-wd' name='finish' value='Finish' />
                </div>

                <div class="pull-left">
                    <input type='button' class='btn btn-previous btn-default btn-wd' name='previous' value='Previous' />
                </div>
                <div class="clearfix"></div>
            </div>
        </form>
    </div>
</div> <!-- wizard container -->
</div>
</div><!-- end row -->
</div> <!--  big container -->
</div>


<!--   Core JS Files   -->
<script src="<?php echo base_url(); ?>adminassets/js/jquery-3.4.1.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>adminassets/js/bootstrap-3.3.5.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>adminassets/js/jquery.bootstrap.wizard.js" type="text/javascript"></script>

<!--  Plugin for the Wizard -->
<script src="<?php echo base_url(); ?>adminassets/js/demo.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>adminassets/js/paper-bootstrap-wizard.js" type="text/javascript"></script>

<!--  More information about jquery.validate here: https://jqueryvalidation.org/     -->
<script src="<?php echo base_url(); ?>adminassets/js/jquery.validate.min.js" type="text/javascript"></script>
<script>
    $("form").on("change", ".file-upload-field", function(){ 
        if($(this).val()){
            $(this).parent(".file-upload-wrapper").attr("data-text", $(this).val().replace(/.*(\/|\\)/, '') );
        }else{
            $(this).parent(".file-upload-wrapper").attr("data-text",'Select your file!');
        }
    });
</script>
</body>

</html>
